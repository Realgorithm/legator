<?php 
echo"hello tabish";
?>
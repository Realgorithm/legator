<div data-elementor-type="header" data-elementor-id="39" class="elementor elementor-39 elementor-location-header">
	<section
		class="elementor-section elementor-top-section elementor-element elementor-element-5d740e0 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default"
		data-id="5d740e0" data-element_type="section">
		<div class="elementor-container elementor-column-gap-custom">
			<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-67a6284"
				data-id="67a6284" data-element_type="column">
				<div class="elementor-widget-wrap elementor-element-populated">
					<div class="elementor-element elementor-element-00c0eed elementor-widget__width-auto elementor-widget elementor-widget-image"
						data-id="00c0eed" data-element_type="widget" data-widget_type="image.default">
						<div class="elementor-widget-container">
							<style>
								/*! elementor - v3.10.0 - 09-01-2023 */
								.elementor-widget-image {
									text-align: center
								}

								.elementor-widget-image a {
									display: inline-block
								}

								.elementor-widget-image a img[src$=".svg"] {
									width: 48px
								}

								.elementor-widget-image img {
									vertical-align: middle;
									display: inline-block
								}
							</style> <img width="300" height="79"
								src="wp-content/uploads/sites/8/2022/10/Logo_GetTrade_1.png"
								class="attachment-full size-full wp-image-40" alt="" loading="lazy">
						</div>
					</div>
				</div>
			</div>
			<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-f516c41"
				data-id="f516c41" data-element_type="column">
				<div class="elementor-widget-wrap elementor-element-populated">
					<div class="elementor-element elementor-element-b33ecb6 elementor-nav-menu__align-right elementor-nav-menu--stretch elementor-nav-menu--dropdown-tablet elementor-nav-menu__text-align-aside elementor-nav-menu--toggle elementor-nav-menu--burger elementor-widget elementor-widget-nav-menu"
						data-id="b33ecb6" data-element_type="widget"
						data-settings="{&quot;submenu_icon&quot;:{&quot;value&quot;:&quot;&lt;i class=\&quot;fas fa-angle-down\&quot;&gt;&lt;\/i&gt;&quot;,&quot;library&quot;:&quot;fa-solid&quot;},&quot;full_width&quot;:&quot;stretch&quot;,&quot;layout&quot;:&quot;horizontal&quot;,&quot;toggle&quot;:&quot;burger&quot;}"
						data-widget_type="nav-menu.default">
						<div class="elementor-widget-container">
							<link rel="stylesheet"
								href="wp-content/plugins/elementor-pro/assets/css/widget-nav-menu.min.css">
							<nav migration_allowed="1" migrated="0" role="navigation"
								class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal e--pointer-none">
								<ul id="menu-1-b33ecb6" class="elementor-nav-menu">
									<li
										class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-6">
										<a href="index.php?page=home" aria-current="page"
											class="elementor-item elementor-item-active">Home</a>
									</li>
									<li
										class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-8">
										<a href="index.php?page=about" class="elementor-item">About Us</a>
										<ul class="sub-menu elementor-nav-menu--dropdown">
											<li
												class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9">
												<a href="index.php?page=about" class="elementor-sub-item">About
													Us</a>
											</li>

											<li
												class="menu-item menu-item-type-custom menu-item-object-custom menu-item-18">
												<a href="index.php?page=faq" class="elementor-sub-item">FAQ</a>
											</li>
										</ul>
									</li>
									<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7">
										<a href="index.php?page=pricing" class="elementor-item"> Pricing</a>
									</li>



									<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10">
										<a href="index.php?page=support" class="elementor-item">Contact</a>
									</li>

									<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7">
										<a href="index.php?page=login" class="elementor-item"> Login</a>
									</li>





								</ul>
							</nav>
							<div class="elementor-menu-toggle" role="button" tabindex="0" aria-label="Menu Toggle"
								aria-expanded="false">
								<i aria-hidden="true" role="presentation"
									class="elementor-menu-toggle__icon--open oi oi-menu"></i><i aria-hidden="true"
									role="presentation" class="elementor-menu-toggle__icon--close eicon-close"></i>
								<span class="elementor-screen-only">Menu</span>
							</div>
							<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" role="navigation"
								aria-hidden="true">
								<ul id="menu-2-b33ecb6" class="elementor-nav-menu">
									<li
										class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-6">
										<a href="index.php?page=home" aria-current="page"
											class="elementor-item elementor-item-active" tabindex="-1">Home</a>
									</li>
									<li
										class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-8">
										<a href="index.php?page=about" class="elementor-item" tabindex="-1">About
											Us</a>
										<ul class="sub-menu elementor-nav-menu--dropdown">
											<li
												class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9">
												<a href="index.php?page=about" class="elementor-sub-item"
													tabindex="-1">About Us</a>
											</li>

											<li
												class="menu-item menu-item-type-custom menu-item-object-custom menu-item-18">
												<a href="index.php?page=faq" class="elementor-sub-item"
													tabindex="-1">FAQ</a>
											</li>
										</ul>
									</li>
									<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7">
										<a href="index.php?page=pricing" class="elementor-item" tabindex="-1">
											Pricing</a>
									</li>

									<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10">
										<a href="index.php?page=support" class="elementor-item"
											tabindex="-1">Contact</a>
									</li>
									<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7">
										<a href="index.php?page=signup" class="elementor-item" tabindex="-1">
											Register</a>
									</li>

									<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10">
										<a href="index.php?page=login" class="elementor-item" tabindex="-1">Login</a>
									</li>
								</ul>
							</nav>
						</div>
					</div>
				</div>
			</div>
			<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-c56bda8"
				data-id="c56bda8" data-element_type="column">
				<div class="elementor-widget-wrap elementor-element-populated">
					<div class="elementor-element elementor-element-237b8c9 elementor-align-right elementor-tablet-align-center elementor-mobile-align-right elementor-widget elementor-widget-button"
						data-id="237b8c9" data-element_type="widget" data-widget_type="button.default">
						<div class="elementor-widget-container">
							<div class="elementor-button-wrapper">
								<a href="index.php?page=signup"
									class="elementor-button-link elementor-button elementor-size-sm" role="button">
									<span class="elementor-button-content-wrapper">
										<span class="elementor-button-text">Open Account</span>
									</span>
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
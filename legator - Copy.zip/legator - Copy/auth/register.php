<?php
include 'conn.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];
    $email = $_POST['email'];
    $email1 = $_POST['email1'];
    $referrerName = $_GET['ref']; // Extract referrer ID from the URL
    $refereeName = $username; // Get the newly registered user's ID

    // Capture current date and time
    $registrationTimestamp = date('Y-m-d H:i:s');

    // Validate the data (you may want to add more validation)
    if (empty($fullname) || empty($username) || empty($password) || empty($password2) || empty($email) || empty($email1)) {
        // Handle validation errors
        echo "All fields are required.";
    } elseif ($password !== $password2) {
        // Handle password mismatch
        echo "Passwords do not match.";
    } else {
        // Hash the password before storing it in the database
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Check if username already exists
        $checkUsernameQuery = "SELECT * FROM userdetails WHERE username = ?";
        $stmtUsername = $connect_db->prepare($checkUsernameQuery);
        $stmtUsername->bind_param("s", $username);
        $stmtUsername->execute();

        if ($stmtUsername->fetch()) {
            // Redirect to the register.html page with an error parameter
            header("Location: ../register.html?error=username_exists");
            $stmtUsername->close();
            $connect_db->close();
            exit();
        }

        $stmtUsername->close();

        // Check if email already exists
        $checkEmailQuery = "SELECT * FROM userdetails WHERE email = ?";
        $stmtEmail = $connect_db->prepare($checkEmailQuery);
        $stmtEmail->bind_param("s", $email);
        $stmtEmail->execute();

        if ($stmtEmail->fetch()) {
            // Redirect to the register.html page with an error parameter
            header("Location: ../register.html?error=email_exists");
            $stmtEmail->close();
            $connect_db->close();
            exit();
        }

        $stmtEmail->close();

        // Insert data into the database (replace 'your_table' with your actual table name)
        // Assume you have columns: fullname, username, password, email
        if($referrerName!==null){
            $stmtrefer="INSERT INTO referrals (referrername, refereename) VALUES (?, ?)";
            $stmtrefer=$connect_db->prepare($stmtrefer);
            $stmtrefer->bind_param("ss", $referrerName,$refereeName);
            $stmtrefer->execute();
        }
        $sql = "INSERT INTO userdetails (fullname, email, pass, username,registration_timestamp) VALUES (?, ?, ?, ?, ?)";
        $sql_user = "INSERT INTO `userinformation` (`total_balance`, `username`, `earning`, `withdraw`, `pending_withdraw`, `deposit`, `referal`, `rigs`, `lastaccess`) VALUES (0, ?, 0, 0, 0, 0, 0, 0, current_timestamp())";

        // Use prepared statements to prevent SQL injection
        $stmt_user = $connect_db->prepare($sql_user);
        $stmt = $connect_db->prepare($sql);
        $stmt_user->bind_param("s", $username);
        $stmt->bind_param("sssss", $fullname, $email, $hashedPassword, $username, $registrationTimestamp);

        // Execute the statement
        if ($stmt->execute()) {
            // Redirect to the dashboard.html page with an error parameter
            header("Location: ../index2.php");
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement and database connection
        $stmt->close();
        $stmtrefer->close();
        $stmt_user->close();
        $connect_db->close();
    }
}
?>
<?php
error_reporting(E_ALL);
// session_start();

// Unset all of the session variables
$_SESSION = array();

// Destroy the session.
session_destroy();

// Ensure that pages are not cached
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

// Redirect to the login page
header("Location: ../index.php?page=home");
exit();
?>

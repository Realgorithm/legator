<div class="card">
    <h5 class="card-header bg-primary text-white">Promotional Tools</h5>
    <div class="card-body">

        <div class="row">
            <div class="col-md-12">
                <img src="../Legatordigitalpro.comimages/125x125.gif" />
                <textarea class="form-control" rows="5"
                    spellcheck="false">&lt;a href="https://Legatordigitalpro.com?ref=abc123"&gt; &lt;img src="https://Legatordigitalpro.comimages/125x125.gif" alt="" width="125" height="125" /&gt; &lt;/a&gt;</textarea>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <img src="../Legatordigitalpro.comimages/468x60.gif" />
                <textarea class="form-control" rows="5"
                    spellcheck="false">&lt;a href="https://Legatordigitalpro.com?ref=abc123"&gt; &lt;img src="https://Legatordigitalpro.comimages/468x60.gif" alt="" width="468" height="60" /&gt; &lt;/a&gt;</textarea>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <img src="../Legatordigitalpro.comimages/728x90.gif" />
                <textarea class="form-control" rows="5"
                    spellcheck="false">&lt;a href="https://Legatordigitalpro.com?ref=abc123"&gt; &lt;img src="https://Legatordigitalpro.comimages/728x90.gif" alt="" width="728" height="90" /&gt; &lt;/a&gt;</textarea>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <img src="../Legatordigitalpro.comimages/1200x150.gif" />
                <textarea class="form-control" rows="5"
                    spellcheck="false">&lt;a href="https://Legatordigitalpro.com?ref=abc123"&gt; &lt;img src="https://Legatordigitalpro.comimages/1200x150.gif" alt="" width="1200" height="150" /&gt; &lt;/a&gt;</textarea>
            </div>
        </div>
        <br /><br /><br />
    </div>
</div>
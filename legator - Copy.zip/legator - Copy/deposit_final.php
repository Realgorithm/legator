
    <div class="card">
        <h5 class="card-header bg-primary text-white">Please confirm your deposit</h5>
        <div class="card-body">
            <br><br>

            Hello
            Kindly deposit into the TRC20 address below and save deposit to start
            mining<br><br>
            TTXYUtaqyDy6f1FqPqrfgApdZW3xQbGrcK<br><br>

            <!-- process_1008.php -->
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Get the selected plan from the form data
                $selectedPlan = $_POST['h_id'];
                $depositAmount = $_POST['amount'];

                // Render data based on the selected plan
                switch ($selectedPlan) {
                    case '1':
                        // Render data for Plan 1
                        $plan = "FIRST ";
                        $profit = "140% in 20 days";
                        $planNo = 1;
                        break;

                    case '2':
                        // Render data for Plan 2
                        $plan = "SECOND ";
                        $profit = "140% in 15 days";
                        $planNo = 2;
                        break;

                    case '3':
                        // Render data for Plan 3
                        $plan = "THIRD ";
                        $profit = "200% in 15 days";
                        $planNo = 3;
                        break;

                    default:
                        // Handle other cases or show an error
                        $data = "Invalid plan selected";
                }

                echo '<div class="table-responsive">
                                            <table class="table">
                                                <tr>
                                                    <th>Plan:</th>
                                                    <td>' . $plan . 'PLAN</td>
                                                </tr>
                                                <tr>
                                                    <th>Profit:</th>
                                                    <td>' . $profit . '</td>
                                                </tr>
                                                <tr>
                                                    <th>Withdrawal fee:</th>
                                                    <td>
                                                        Available with
                                                        5% withdrawal fee </td>
                                                </tr>
                                                <tr>
                                                    <th>Compound:</th>
                                                    <td>0%</td>
                                                </tr>

                                                <tr>
                                                    <th>Amount:</th>
                                                    <td>' . $depositAmount . '</td>
                                                </tr>
                                                
                                            </table>
                                        </div>';
            }
            ?>

            <form name=spend method=post action="auth/deposit_auth.php">
                <table class="table">
                    <tr>
                        <th>Transaction Id:</th>
                        <td>
                            <input type="text" name=amount value=<?php echo $depositAmount ?> hidden>
                            <input type="text" name=plan value=<?php echo $planNo ?> hidden>
                            <input type=text id=depositid name=depositid value='' class="form-control" size=15
                                placeholder="Enter the transaction id">
                        </td>
                    </tr>
                </table>
                <br><input type=submit value="Save" class="btn btn-primary ml-auto">
                &nbsp;
                <input type=button class="btn btn-primary ml-auto" value="Cancel"
                    onclick="document.location='index2017.php?a=deposit'">
            </form>


        </div>
    </div>